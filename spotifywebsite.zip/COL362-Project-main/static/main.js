var changeColor = document.querySelector(".nav justify-content-end")
changeColor.style.backgroundColor = '#00ac00';